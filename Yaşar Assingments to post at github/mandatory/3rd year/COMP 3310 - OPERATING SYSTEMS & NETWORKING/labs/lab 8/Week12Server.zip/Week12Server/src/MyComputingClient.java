/* CLIENT */
import java.io.*;
import java.net.*;
public class MyComputingClient {

    public static void main(String args[]) {

        Socket client = null;

        // Default port number we are going to use
        int portnumber = 1234;
        if (args.length >= 1){
            portnumber = Integer.parseInt(args[0]);
        }

        for (int i=0; i <10; i++) {
            try {
                String msg = "";

// Create a client socket
                client = new Socket(InetAddress.getLocalHost(), portnumber);
                System.out.println("Client socket is created " + client);


                // Create an output stream of the client socket
                OutputStream clientOut0 = client.getOutputStream();
                PrintWriter pw0 = new PrintWriter(clientOut0, true);

                // Create an input stream of the client socket
                InputStream clientIn0 = client.getInputStream();
                BufferedReader br0 = new BufferedReader(new
                        InputStreamReader(clientIn0));

                // Create BufferedReader for a standard input
                BufferedReader stdIn0 = new BufferedReader(new
                        InputStreamReader(System.in));

                System.out.println("Enter first number: ");

                // Read data from standard input device and write it
                // to the output stream of the client socket.
                msg += stdIn0.readLine().trim();

                //pw0.println(msg);

/*
                // Create an output stream of the client socket
                OutputStream clientOut2 = client.getOutputStream();
                PrintWriter pw2 = new PrintWriter(clientOut2, true);

                // Create an input stream of the client socket
                InputStream clientIn2 = client.getInputStream();
                BufferedReader br2 = new BufferedReader(new
                        InputStreamReader(clientIn2));

                // Create BufferedReader for a standard input
                BufferedReader stdIn2 = new BufferedReader(new
                        InputStreamReader(System.in));

                System.out.println("Enter second");
                msg += stdIn2.readLine().trim();
                //pw2.println(msg);
                */

                // Create an output stream of the client socket
                OutputStream clientOut = client.getOutputStream();
                PrintWriter pw = new PrintWriter(clientOut, true);

                // Create an input stream of the client socket
                InputStream clientIn = client.getInputStream();
                BufferedReader br = new BufferedReader(new
                        InputStreamReader(clientIn));

                // Create BufferedReader for a standard input
                BufferedReader stdIn = new BufferedReader(new
                        InputStreamReader(System.in));

                System.out.println("Enter your desired operation:\n + -> Addition\n- -> subtraction\n* -> multiplication\n/ -> division");

                // Read data from standard input device and write it
                // to the output stream of the client socket.
                msg += stdIn.readLine().trim();
                //pw.println(msg);




                // Create an output stream of the client socket
                OutputStream clientOut1 = client.getOutputStream();
                PrintWriter pw1 = new PrintWriter(clientOut1, true);

                // Create an input stream of the client socket
                InputStream clientIn1 = client.getInputStream();
                BufferedReader br1 = new BufferedReader(new
                        InputStreamReader(clientIn1));

                // Create BufferedReader for a standard input
                BufferedReader stdIn1 = new BufferedReader(new
                        InputStreamReader(System.in));

                System.out.println("Enter second number: ");

                // Read data from standard input device and write it
                // to the output stream of the client socket.





                //System.out.println("Result -> ");

                // Read data from standard input device and write it
                // to the output stream of the client socket.
                msg += stdIn1.readLine().trim();
                //msg += stdIn.readLine().trim() + stdIn1.readLine().trim() + stdIn2.readLine().trim();
                //pw1.println(msg);

                // Create an output stream of the client socket
                OutputStream clientOut3 = client.getOutputStream();
                PrintWriter pw3 = new PrintWriter(clientOut3, true);

                // Create an input stream of the client socket
                InputStream clientIn3 = client.getInputStream();
                BufferedReader br3 = new BufferedReader(new
                        InputStreamReader(clientIn3));

                // Create BufferedReader for a standard input
                BufferedReader stdIn3 = new BufferedReader(new
                        InputStreamReader(System.in));
                pw3.println(msg);


                // Read data from the input stream of the client socket.
                System.out.println("Result of operation is " + br3.readLine());

                pw.close();
                pw0.close();
                pw1.close();
                //pw2.close();
                pw3.close();

                br.close();
                br1.close();
                br0.close();
                //br2.close();
                br3.close();

                client.close();

                // Stop the operation
                if (msg.equalsIgnoreCase("Bye")) {
                    break;
                }

            } catch (IOException ie) {
                System.out.println("I/O error " + ie);
            }
        }
    }
}