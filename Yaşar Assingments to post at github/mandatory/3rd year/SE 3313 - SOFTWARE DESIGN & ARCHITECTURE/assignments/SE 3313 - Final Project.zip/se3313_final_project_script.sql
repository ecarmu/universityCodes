/*drop schema `se3313_proje` ;*/
CREATE SCHEMA IF NOT EXISTS `se3313_proje` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `se3313_proje`;

DROP TABLE IF EXISTS `coffee_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coffee_log` (
  `filledCoffee` INT NOT NULL,
  `date_of_the_operation` DATETIME DEFAULT NULL
);

DROP TABLE IF EXISTS `coffee_maker`;
CREATE TABLE `coffee_maker` (
  `totalCups` INT not null,
  `state` VARCHAR(45) not null
);

INSERT INTO se3313_proje.coffee_maker VALUES (0, 'empty');