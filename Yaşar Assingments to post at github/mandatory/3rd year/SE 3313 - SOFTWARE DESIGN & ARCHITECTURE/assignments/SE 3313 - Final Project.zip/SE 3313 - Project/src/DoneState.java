public class DoneState implements State{
    CoffeeMakerGUI coffeeMaker;

    public DoneState(CoffeeMakerGUI coffeeMaker) {
        this.coffeeMaker = coffeeMaker;
    }

    @Override
    public void start() {
        coffeeMaker.errorMessage("You can't start coffee machine !! Coffee machine is already done...");
    }

    @Override
    public void filled() {
        coffeeMaker.errorMessage("You can't fill coffee machine !! Coffee machine is already done...");
    }

    @Override
    public void reset() {
        try {
            coffeeMaker.addMessage("Coffee machine is successfully resetted !!!");
            coffeeMaker.setState(coffeeMaker.emptyState);
            coffeeMaker.database.updateState("empty");
            coffeeMaker.filledTextField.setText("");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
