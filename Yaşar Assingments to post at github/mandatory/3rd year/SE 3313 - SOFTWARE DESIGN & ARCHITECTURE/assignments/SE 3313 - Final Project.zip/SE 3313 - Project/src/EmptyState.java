import java.sql.SQLException;

public class EmptyState implements State{
    CoffeeMakerGUI coffeeMaker;

    public EmptyState(CoffeeMakerGUI coffeeMaker) {
        this.coffeeMaker = coffeeMaker;
    }

    @Override
    public void start() {
        coffeeMaker.errorMessage("You can't start without filling!");
    }

    @Override
    public void filled() {
        try {
            // Attempt to convert the String to Integer
            System.out.println(coffeeMaker.filledTextField.getText());
            int filledAmount = Integer.parseInt(coffeeMaker.filledTextField.getText());

            if(filledAmount < 1)
                coffeeMaker.errorMessage("Filled amount can't be smaller than 1");

            // Now you can use 'filledAmount' as an Integer
            coffeeMaker.addMessage("Filled amount is " + filledAmount);
            coffeeMaker.setState(coffeeMaker.idleState);
            coffeeMaker.database.updateState("idle");
        } catch (NumberFormatException e) {
            // Handle the case where the String cannot be converted to an Integer
            coffeeMaker.errorMessage("Filled amount is not an integer");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void reset() {
        coffeeMaker.errorMessage("You can't reset an empty coffee machine !!");
    }
}
