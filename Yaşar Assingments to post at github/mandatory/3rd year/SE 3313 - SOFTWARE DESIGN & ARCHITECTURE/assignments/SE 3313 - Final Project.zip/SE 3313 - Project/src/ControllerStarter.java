public class ControllerStarter extends Controller{

    ControllerStarter(CoffeeMakerGUI coffeeMakerGUI){
        stateBehaviour = new StartBehaviour();
        coffeeMaker = coffeeMakerGUI;
    }
}
