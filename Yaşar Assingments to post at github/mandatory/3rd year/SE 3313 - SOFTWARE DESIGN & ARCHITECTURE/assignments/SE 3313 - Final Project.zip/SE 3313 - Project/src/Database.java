import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Properties;

public class Database implements Model{
    ArrayList<View> viewList;
    public int requestedFilledAmountData;
    public int currentFilledAmount;
    public State state;

    Database(){
        viewList = new ArrayList<>();
    }

    public static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";

    // hocam, kendi database bilgilerinizi bu değişkenlere verin
    public static final String USERNAME = "";
    public static final String PASSWORD = "";
    public static final String schemaName = "se3313_proje";
    public static final String MAX_POOL = "250";

    public static final String databaseName = "coffee_maker";

    public static final String DATABASE_URL = "jdbc:mysql://localhost/" + schemaName +
            "?user=" + USERNAME +
            "&password=" + PASSWORD +
            "&useUnicode=true&characterEncoding=UTF-8&useSSL=false&allowPublicKeyRetrieval=true";


    public Connection connection;

    public Properties properties;

    public void initDB(){
        this.connection = connect();

        try {

            resetDB();
            resetCoffeeLogs();

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void resetDB() throws Exception{
        updateState("empty");
        requestedFilledAmountData = 0;
        setTotalCups(0);

        resetCoffeeLogs();

    }


    // create properties
    public Properties getProperties() {
        if (properties == null) {
            properties = new Properties();
            properties.setProperty("user", USERNAME);
            properties.setProperty("password", PASSWORD);
            properties.setProperty("MaxPooledStatements", MAX_POOL);
        }
        return properties;
    }

    // connect database
    public Connection connect() {
        if (connection == null) {
            try {
                Class.forName(DATABASE_DRIVER);
                // Use the URL with user and password parameters
                connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }


    // disconnect database
    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public int getAmountOfTotalCups() {
        // SQL query to select the value of the "totalCups" column
        String selectSql = "SELECT totalCups FROM " + databaseName;

        try {
            PreparedStatement pst = connection.prepareStatement(selectSql);
            ResultSet resultSet = pst.executeQuery();

            // Check if there is a result
            if (resultSet.next()) {
                // Retrieve the value of the "totalCups" column from the result set
                int totalCups = resultSet.getInt("totalCups");
                currentFilledAmount = totalCups;
                return totalCups;
            }
        }catch (Exception e){
            e.printStackTrace();
        }



        // Return a default value or indicate an error condition
        return -1;
    }

    public String getState() throws SQLException {
        // SQL query to select the value of the "totalCups" column
        String selectSql = "SELECT state FROM " + databaseName;

        //try (Connection connection = connect();
         PreparedStatement pst = connection.prepareStatement(selectSql);
         ResultSet resultSet = pst.executeQuery();

        // Check if there is a result
        if (resultSet.next()) {
            // Retrieve the value of the "totalCups" column from the result set
            String state = resultSet.getString("state");
            return state;
        }

        // Return a default value or indicate an error condition
        return "ERROR";
    }

    public void updateState(String newState) throws SQLException {
        // SQL query to update the value of the "state" column
        String updateSql = "UPDATE " + databaseName + " SET state = ?";


        PreparedStatement pst = connection.prepareStatement(updateSql);

        // Set the new state value in the prepared statement
        pst.setString(1, newState);

        // Execute the update statement
        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated > 0) {
            System.out.println("State updated successfully.");
            notifyObservers();
        } else {
            System.err.println("Failed to update state.");
        }

    }

    public void requestToSetFilled(int filledCount){
        requestedFilledAmountData = filledCount;
    }



    public void updateTotalCups() throws SQLException {
        // SQL statement to update the "totalCups" column by a given integer
        String updateSql = "UPDATE " + databaseName + " SET totalCups = totalCups + ?";

        PreparedStatement pst = connection.prepareStatement(updateSql);
        // Set the parameter value for the increaseBy variable
        pst.setInt(1, requestedFilledAmountData);

        requestedFilledAmountData = 0;

        // Execute the update statement
        int rowsAffected = pst.executeUpdate();

        System.out.println("Database update successful. New value of 'total cups' is " + requestedFilledAmountData);

        notifyObservers();
    }

    public void setTotalCups(int newTotalCups) throws SQLException {
        // SQL statement to update the "totalCups" column to a specific value
        String updateSql = "UPDATE " + databaseName + " SET totalCups = ?";

        PreparedStatement pst = connection.prepareStatement(updateSql);

        // Set the parameter value for the newTotalCups variable
        pst.setInt(1, newTotalCups);

        // Execute the update statement
        int rowsAffected = pst.executeUpdate();

        System.out.println("Database update successful. New value of 'total cups' is " + newTotalCups);

        notifyObservers();
    }

    public void insertCoffeeLog() {
        String insertSql = "INSERT INTO coffee_log (filledCoffee, date_of_the_operation) VALUES (?, ?)";

        try {
            // Get the current date and time
            LocalDateTime currentDateTime = LocalDateTime.now();

            // Convert LocalDateTime to java.sql.Timestamp
            Timestamp timestamp = Timestamp.valueOf(currentDateTime);

            PreparedStatement pst = connection.prepareStatement(insertSql);
            pst.setInt(1, requestedFilledAmountData);
            pst.setTimestamp(2, timestamp);

            int rowsInserted = pst.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("Coffee log inserted successfully.");
            } else {
                System.err.println("Failed to insert coffee log.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void resetCoffeeLogs() {
        try {

            // Create the DELETE SQL query
            String deleteQuery = "DELETE FROM coffee_log";

            // Prepare the statement
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);

            // Execute the query to delete all rows
            int rowsDeleted = preparedStatement.executeUpdate();

            System.out.println(rowsDeleted + " rows deleted from the table.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void registerObserver(View v) {
        viewList.add(v);
    }

    @Override
    public void removeObserver(View v) {
        int i = viewList.indexOf(v);
        if(i>=0)
            viewList.remove(i);
    }

    @Override
    public void notifyObservers() {
        for (View v: viewList) {
            try {
                v.update(getAmountOfTotalCups(), getState());
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Database model = new Database();
        try {
            /*model.connect();
            model.requestToSetFilled(0);
            System.out.println(model.requestedFilledAmountData + " VS " + model.getAmountOfTotalCups());
            model.updateTotalCups();

            //System.out.println(model.getAmountOfTotalCups());
            //model.updateRowAtSQLTable(0);
            System.out.println(model.getAmountOfTotalCups());*/

            model.initDB();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}