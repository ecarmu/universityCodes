import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;

public class CoffeeMakerGUI implements View {

    ArrayList<View> components;
    public State brewingState;
    public State doneState;
    public State emptyState;
    public State idleState;
    public State state;
    Database database;
    public JTextField filledTextField;
    public ViewCompositePacket mainPacket;
    Timer timer;

    @Override
    public void update(int totalCups, String state) {
        for (View v : components) {
            v.update(totalCups, state);
        }
    }

    public void setState(State state){
        this.state = state;
    }

    public void initGUI(){

        database = new Database();
        database.initDB();

        brewingState = new BrewingState(this);
        idleState = new IdleState(this);
        doneState = new DoneState(this);
        emptyState = new EmptyState(this);

        state = emptyState;

        mainPacket = new ViewCompositePacket(database);

        ViewPacket filledPacket = new ViewPacket(database);
        ViewElement filledButton = new ViewElement(new JButton("FILLED"), database);
        filledButton.component.setBackground(Color.WHITE);

        JTextField filledTextFieldd = new JTextField("");
        filledTextFieldd.setHorizontalAlignment(JTextField.CENTER);
        filledTextFieldd.setFont(new Font(filledTextFieldd.getFont().getName(), Font.BOLD, 14));
        ViewElement filledTextFieldElement = new ViewElement(filledTextFieldd, database);


        ((JButton) filledButton.component).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controller fillControl = new ControllerFilller(CoffeeMakerGUI.this);
                filledTextField = (JTextField) filledTextFieldElement.component;
                fillControl.performStateOperation();
            }
        });

        filledPacket.componentsPacket.add(filledButton);
        filledPacket.componentsPacket.add(filledTextFieldElement);

        ViewPacket startPacket = new ViewPacket(database);
        ViewElement startButton = new ViewElement(new JButton("START"), database);
        startButton.component.setBackground(Color.WHITE);

        ((JButton) startButton.component).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controller startControl = new ControllerStarter(CoffeeMakerGUI.this);
                startControl.performStateOperation();
            }
        });

        URL imageUrl = CoffeeMakerGUI.class.getResource("img.png");
        ImageIcon imageIcon = new ImageIcon(imageUrl);
        Image scaledImage = imageIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(scaledImage);
        JLabel startImageLabel = new JLabel(scaledImageIcon);
        startImageLabel.setHorizontalAlignment(JLabel.CENTER);
        startButton.component.setLayout(new FlowLayout(FlowLayout.CENTER));
        startButton.component.add(startImageLabel);

        ViewPacket statePacket = new ViewPacket(database);
        ViewElement idleElement = new ViewElement(new JLabel("IDLE", SwingConstants.CENTER), database);
        idleElement.component.setBackground(Color.WHITE);
        idleElement.component.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
        ViewElement brewingElement = new ViewElement(new JLabel("BREWING", SwingConstants.CENTER), database);
        brewingElement.component.setBackground(Color.WHITE);
        brewingElement.component.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
        ViewElement doneElement = new ViewElement(new JLabel("DONE", SwingConstants.CENTER), database);
        doneElement.component.setBackground(Color.WHITE);
        doneElement.component.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));

        JPanel statePanel = new JPanel(new GridLayout(3, 1));
        statePanel.setBackground(Color.WHITE);
        statePanel.add(idleElement.component);
        statePanel.add(brewingElement.component);
        statePanel.add(doneElement.component);

        statePacket.componentsPacket.add(new ViewElement(statePanel, database));

        startPacket.componentsPacket.add(startButton);
        startPacket.componentsPacket.add(statePacket.componentsPacket.get(0));

        ViewPacket totalCupsPacket = new ViewPacket(database);
        ViewElement totalCupsButton = new ViewElement(new JButton("Total Cups"), database);
        totalCupsButton.component.setBackground(Color.WHITE);

        ViewElement totalCup_AmountElement = new ViewElement(new JPanel(), database);
        totalCup_AmountElement.component.setBackground(Color.WHITE);
        totalCup_AmountElement.component.add(new JLabel(String.valueOf(database.getAmountOfTotalCups()), SwingConstants.CENTER));

        totalCupsPacket.componentsPacket.add(totalCupsButton);
        totalCupsPacket.componentsPacket.add(totalCup_AmountElement);


        ((JButton) totalCupsButton.component).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controller visibilityControl = new ControllerVisibilityChanger(CoffeeMakerGUI.this);
                visibilityControl.performVisibilityOperation((JLabel)totalCupsPacket.componentsPacket.get(1).component.getComponent(0));
            }
        });

        ViewPacket resetPacket = new ViewPacket(database);
        ViewElement resetButton = new ViewElement(new JButton("Reset"), database);
        resetButton.component.setBackground(Color.WHITE);

        ((JButton) resetButton.component).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controller resetControl = new ControllerResetter(CoffeeMakerGUI.this);
                resetControl.performStateOperation();
            }
        });

// Use a GridLayout with a single row for resetPacket
        resetPacket.componentsPacket.add(new ViewElement(new JPanel(new GridLayout(1, 1)), database));
        resetPacket.componentsPacket.add(resetButton);


        ViewPacket warningPacket = new ViewPacket(database);
        ViewElement warningElement = new ViewElement(new JPanel(), database);
        warningElement.component.add(new JLabel("Messages / Warnings..."), BorderLayout.NORTH);
        warningElement.component.setForeground(Color.RED);
        warningElement.component.setBackground(Color.WHITE);
        ViewElement messageElement = new ViewElement(new JPanel(), database);
        messageElement.component.add(new JLabel(), BorderLayout.CENTER);
        messageElement.component.setBackground(Color.WHITE);
        warningPacket.componentsPacket.add(warningElement);
        warningPacket.componentsPacket.add(messageElement);

        mainPacket.packetsPacket.add(filledPacket);
        mainPacket.packetsPacket.add(startPacket);
        mainPacket.packetsPacket.add(totalCupsPacket);
        mainPacket.packetsPacket.add(resetPacket);
        mainPacket.packetsPacket.add(warningPacket);

        // Assuming there's a method to convert ViewPacket to View
        database.viewList.addAll(mainPacket.packetsPacket);

        components = new ArrayList<>();
        components.add(filledButton);
        components.add(filledTextFieldElement);
        components.add(startButton);
        components.add(idleElement);
        components.add(brewingElement);
        components.add(doneElement);
        components.add(totalCupsButton);
        components.add(totalCup_AmountElement);
        components.add(resetButton);
        components.add(warningElement);
        components.add(messageElement);

        JFrame frame = new JFrame();
        frame.setLayout(new GridLayout(6, 2));

        for (ViewPacket packet : mainPacket.packetsPacket) {
            for (ViewElement element : packet.componentsPacket) {
                frame.getContentPane().add(element.component);
            }
        }

        // Set frame properties
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void executeTimer(int delay){
        timer = new Timer(1000, new ActionListener() {
            int count = 5;



            @Override
            public void actionPerformed(ActionEvent e) {
                ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setText("Countdown: " + count);
                ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setForeground(Color.DARK_GRAY);
                count--;

                if (count < 0) {
                    ((Timer) e.getSource()).stop(); // Stop the timer when count reaches 0
                    ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setText("");
                    // Add any actions you want to perform when the countdown is complete

                    try {
                        setState(doneState);
                        database.updateState("done");
                        database.insertCoffeeLog();
                        database.updateTotalCups();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }

                }
            }
        });

        // Start the timer
        timer.start();
    }

    public void start() {
        state.start();
    }

    public void filled() {
        state.filled();
    }

    public void reset() {
        state.reset();
    }

    public static void main(String[] args) {
        CoffeeMakerGUI coffeeMaker = new CoffeeMakerGUI();
        coffeeMaker.initGUI();
    }

    public void errorMessage(String s) {
        ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setText(s);
        ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setForeground(Color.RED);
    }

    public void addMessage(String s) {
        ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setText(s);
        ((JLabel) ((JPanel) mainPacket.packetsPacket.get(4).componentsPacket.get(1).component).getComponent(0)).setForeground(Color.GREEN);
    }
}
