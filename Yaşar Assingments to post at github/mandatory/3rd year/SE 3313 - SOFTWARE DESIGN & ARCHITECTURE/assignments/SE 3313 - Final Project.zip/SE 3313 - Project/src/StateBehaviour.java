public interface StateBehaviour {
    void stateOperation(CoffeeMakerGUI coffeeMaker);
}
