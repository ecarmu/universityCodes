public class BrewingState implements State {
    CoffeeMakerGUI coffeeMaker;

    public BrewingState(CoffeeMakerGUI coffeeMaker) {
        this.coffeeMaker = coffeeMaker;
    }

    @Override
    public void start() {
        coffeeMaker.errorMessage("You can't start coffee machine !! Coffee machine is already brewing...\nPlease just wait for timer to expire");
    }

    @Override
    public void filled() {
        coffeeMaker.errorMessage("You can't fill coffee machine !! Coffee machine is already brewing...\nPlease just wait for timer to expire");
    }

    @Override
    public void reset() {
        coffeeMaker.errorMessage("You can't reset coffee machine !! Coffee machine is already brewing...\nPlease just wait for timer to expire");
    }
}
