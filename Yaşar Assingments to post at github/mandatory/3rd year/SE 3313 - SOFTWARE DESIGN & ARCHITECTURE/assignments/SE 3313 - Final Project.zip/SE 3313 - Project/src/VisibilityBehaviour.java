import javax.swing.*;

public interface VisibilityBehaviour {
    void visibilityOperation(JComponent jComponent);
}
