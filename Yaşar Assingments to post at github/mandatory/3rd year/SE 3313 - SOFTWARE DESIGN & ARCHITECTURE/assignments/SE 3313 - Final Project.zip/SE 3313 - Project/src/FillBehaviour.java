public class FillBehaviour implements StateBehaviour{

    @Override
    public void stateOperation(CoffeeMakerGUI coffeeMaker) {
        coffeeMaker.filled();

        try{
            /*System.out.println(coffeeMaker);
            System.out.println(coffeeMaker.database);
            System.out.println(coffeeMaker.filledTextField);
             */
            coffeeMaker.database.requestToSetFilled(Integer.parseInt(coffeeMaker.filledTextField.getText()));
            coffeeMaker.database.updateState("idle");
        }catch (Exception e){
            // e.printStackTrace();
        }
    }
}
