public class ControllerVisibilityChanger extends Controller{

    public ControllerVisibilityChanger(CoffeeMakerGUI coffeeMakerGUI){
        controlBehaviour = new ChangeVisibilty();
        coffeeMaker = coffeeMakerGUI;
    }
}