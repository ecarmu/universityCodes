public interface State {
    void start();
    void filled();
    void reset();
}
