import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;

public class ViewPacket implements View{
    
    ArrayList<ViewElement> componentsPacket;
    Model database;

    ViewPacket(Model database){
        this.database = database;
        database.registerObserver(this);
        componentsPacket = new ArrayList<>();
    }
    
    @Override
    public void update(int totalCups, String state) {
        for (ViewElement viewComponent : componentsPacket) {

            if(viewComponent.component instanceof JPanel && viewComponent.component.getComponentCount() > 0 && viewComponent.component.getComponent(0) instanceof JLabel){
                try {
                    int deger = Integer.parseInt(((JLabel) viewComponent.component.getComponent(0)).getText());
                    viewComponent.update(totalCups, state);
                    break;
                } catch (NumberFormatException e) {
                    // parseInt başarısız oldu, girilen değer bir integer değil
                }
            }

            if(viewComponent.component instanceof JPanel && viewComponent.component.getComponentCount() > 1){
                if(
                Objects.equals(((JLabel) viewComponent.component.getComponent(0)).getText(), "IDLE") ||
                Objects.equals(((JLabel) viewComponent.component.getComponent(1)).getText(), "BREWING") ||
                Objects.equals(((JLabel) viewComponent.component.getComponent(2)).getText(), "DONE") ){
                    for (Component component : viewComponent.component.getComponents()) {
                        // Check if the component is a JLabel
                        if (component instanceof JLabel) {
                            // Return the found JLabel
                            viewComponent.update(totalCups, state);
                        }
                    }
                }



            }


        }
    }
}
