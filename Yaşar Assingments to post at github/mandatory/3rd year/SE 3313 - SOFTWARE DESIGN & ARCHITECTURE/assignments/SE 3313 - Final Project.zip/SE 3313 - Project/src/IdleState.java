public class IdleState implements State{
    CoffeeMakerGUI coffeeMaker;

    public IdleState(CoffeeMakerGUI coffeeMaker) {
        this.coffeeMaker = coffeeMaker;
    }

    @Override
    public void start() {
        try{
            coffeeMaker.addMessage("Coffee machine started successfully");
            coffeeMaker.setState(coffeeMaker.brewingState);
            coffeeMaker.database.updateState("brewing");

            coffeeMaker.executeTimer(1000);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void filled() {
        coffeeMaker.errorMessage("You can't fill coffee machine !! Coffee machine is idle");
    }

    @Override
    public void reset() {
        coffeeMaker.errorMessage("You can't reset an idle coffee machine !!");
    }
}
