import javax.swing.*;

public class ChangeVisibilty implements VisibilityBehaviour{

    @Override
    public void visibilityOperation(JComponent jComponent) {
        if(jComponent instanceof JLabel)
            ((JLabel) jComponent).setVisible(!((JLabel) jComponent).isVisible());
    }

    // setVisibility


}
