public class StartBehaviour implements StateBehaviour{

    @Override
    public void stateOperation(CoffeeMakerGUI coffeeMaker) {
        coffeeMaker.start();
    }
}
