public class ControllerResetter extends Controller{

    ControllerResetter(CoffeeMakerGUI coffeeMakerGUI){
        stateBehaviour = new ResetBehaviour();
        coffeeMaker = coffeeMakerGUI;
    }
}
