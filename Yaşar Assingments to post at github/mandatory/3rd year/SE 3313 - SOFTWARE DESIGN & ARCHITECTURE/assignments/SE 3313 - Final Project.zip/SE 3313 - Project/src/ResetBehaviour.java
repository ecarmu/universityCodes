public class ResetBehaviour implements StateBehaviour{
    @Override
    public void stateOperation(CoffeeMakerGUI coffeeMaker) {
        coffeeMaker.reset();
    }
}
