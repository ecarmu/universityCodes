public interface View {
    void update(int totalCups, String state);
}
