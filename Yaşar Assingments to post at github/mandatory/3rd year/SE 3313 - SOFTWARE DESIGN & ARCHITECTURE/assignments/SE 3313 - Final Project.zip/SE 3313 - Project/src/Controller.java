import javax.swing.*;

public abstract class Controller {
    VisibilityBehaviour controlBehaviour;
    StateBehaviour stateBehaviour;

    CoffeeMakerGUI coffeeMaker;
    Model model;

    public void performVisibilityOperation(JComponent jComponent){
        controlBehaviour.visibilityOperation(jComponent);
    }

    public void performStateOperation(){
        stateBehaviour.stateOperation(coffeeMaker);
    }
}
