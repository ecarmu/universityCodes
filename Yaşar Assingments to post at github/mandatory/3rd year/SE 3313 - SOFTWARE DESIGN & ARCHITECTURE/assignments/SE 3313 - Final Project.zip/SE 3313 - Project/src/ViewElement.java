import javax.swing.*;
import java.awt.*;
import java.util.Locale;
import java.util.Objects;

public class ViewElement implements View{

    JComponent component;

    public int totalCups;
    public State state;
    Model database;

    ViewElement(JComponent component, Model database){
        this.component = component;
        this.database = database;
        database.registerObserver(this);
    }

    @Override
    public void update(int totalCups, String state) {

        if(component instanceof JPanel){


            for (int i = 0; i < this.component.getComponentCount(); i++) {
                if(Objects.equals(((JLabel) this.component.getComponent(i)).getText().toLowerCase(Locale.ROOT), state))
                    this.component.getComponent(i).setBackground(Color.YELLOW);
                else
                    this.component.getComponent(i).setBackground(Color.WHITE);
                ((JLabel) this.component.getComponent(i)).setOpaque(true);

            }


        }



        if(this.component instanceof JPanel && this.component.getComponentCount() > 0 && this.component.getComponent(0) instanceof JLabel){


            try {
                int deger = Integer.parseInt((((JLabel) this.component.getComponent(0)).getText()));
                ((JLabel) this.component.getComponent(0)).setText(String.valueOf(totalCups));

                ((JLabel) this.component.getComponent(0)).setOpaque(false);
            } catch (NumberFormatException e) {
                // parseInt başarısız oldu, girilen değer bir integer değil
            }


        }





    }
}
