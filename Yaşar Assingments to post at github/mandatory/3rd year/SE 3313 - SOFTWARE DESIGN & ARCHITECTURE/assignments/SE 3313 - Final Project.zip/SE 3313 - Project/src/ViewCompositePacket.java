import javax.swing.*;
import java.util.ArrayList;

public class ViewCompositePacket implements View{

    public ArrayList<ViewElement> componentsPacket;
    public ArrayList<ViewPacket> packetsPacket;

    public int totalCups;
    public State state;
    Model database;

    ViewCompositePacket(Model database){
        componentsPacket = new ArrayList<>();
        packetsPacket = new ArrayList<>();
        this.database = database;
        database.registerObserver(this);
    }

    @Override
    public void update(int totalCups, String state) {
        for (ViewPacket packets : packetsPacket) {
            packets.update(totalCups, state);
        }
    }
}
