public class ControllerFilller extends Controller{

    ControllerFilller(CoffeeMakerGUI coffeeMaker){
        stateBehaviour = new FillBehaviour();
        this.coffeeMaker = coffeeMaker;
    }
}
