public interface Model {
    void registerObserver(View v);
    void removeObserver(View v);
    void notifyObservers();
}
