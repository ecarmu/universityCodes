public class InvalidTotalGoalsException extends Exception{

    InvalidTotalGoalsException(){
        super();
    }
}
