public class ThirdTeamException extends Exception{

    ThirdTeamException(){
        super();
    }
}
