public class Main {

    public static void main(String[] args) {
        MatchWinnerFinder finder1 = new MatchWinnerFinder();
    }
}
