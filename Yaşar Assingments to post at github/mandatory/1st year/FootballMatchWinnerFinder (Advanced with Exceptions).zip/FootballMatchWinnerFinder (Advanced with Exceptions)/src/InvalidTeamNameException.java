public class InvalidTeamNameException extends Exception{
    InvalidTeamNameException(){
        super();
    }
}
