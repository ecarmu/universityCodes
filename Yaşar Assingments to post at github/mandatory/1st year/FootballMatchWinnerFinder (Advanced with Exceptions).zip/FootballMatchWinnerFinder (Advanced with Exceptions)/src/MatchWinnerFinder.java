import java.util.Objects;
import java.util.Scanner;

public class MatchWinnerFinder {
    String teamFirst;
    int goalsOfTeamFirst = 0;

    String teamSecond;
    int goalsOfTeamSecond = 0;

    int totalGoals;


    /*ilk girilen takım team1
    ikinci girilen takım Team2
    -> 3. takım girmek hata
    -> büyük harfsiz takım girmemek hata
    -> "" gibisinden karaktersiz girmek hata
    -> 10 karakterden fazla isimli takım girmek hata

    total goal : while döngüsünün ne kadar çalışacağını gösterir
            -> total goal 1 <= n <= 100: Yani, negatif de; 0 da; 101 falan da olamaz
            -> maç berabere bitmiş olamaz. Çünkü bir final maçı */

    MatchWinnerFinder() {
        while (totalGoals<1 || totalGoals>100) {
            try{
                Scanner scanner = new Scanner(System.in);
                totalGoals = scanner.nextInt();
                checkInvalidTotalGoalsException(totalGoals);
            }
            catch (InvalidTotalGoalsException i){
                continue;
            }

        }


        do {
            try {
                Scanner scanner1 = new Scanner(System.in);
                teamFirst = scanner1.nextLine();
                checkInvalidTeamNameException(teamFirst);
            } catch (InvalidTeamNameException i) {
                teamFirst = "";
            }
        }while (Objects.equals(teamFirst, ""));

        int nth_goal_scored = 1;
        goalsOfTeamFirst++;

        String teamCheck = "";
        boolean teamSecondNotFound = true;


        while (nth_goal_scored < totalGoals) {

            try {
                Scanner scanner2 = new Scanner(System.in);
                teamCheck = scanner2.nextLine();

                checkInvalidTeamNameException(teamCheck);

                if (!teamSecondNotFound)
                    checkThirdTeamExc(teamCheck);

            } catch (InvalidTeamNameException e) {
                continue;
            } catch (ThirdTeamException t) {
                continue;
            }


            if (!Objects.equals(teamCheck, teamFirst) && teamSecondNotFound) {
                teamSecond = teamCheck;
                teamSecondNotFound = !teamSecondNotFound;
            }

            if (Objects.equals(teamCheck, teamFirst)) {
                goalsOfTeamFirst++;
            } else {
                goalsOfTeamSecond++;
            }

            teamCheck = "";
            nth_goal_scored++;
        }

        if (goalsOfTeamFirst > goalsOfTeamSecond) {
            System.out.println(teamFirst);
        } else if (goalsOfTeamSecond > goalsOfTeamFirst) {
            System.out.println(teamSecond);
        }
        else {
            System.out.println("Final maçı berabere kalamaz... ");
        }

    }

    void checkThirdTeamExc(String teamCheck) throws ThirdTeamException {
        if (Objects.equals(teamCheck, teamFirst) || Objects.equals(teamCheck, teamSecond)) {
            return;
        } else {
            System.out.println("Olmayan 3. bir takımı (" + teamCheck + ") girdiniz. Lütfen yeniden deneyiniz.... ");
            throw new ThirdTeamException();
        }
    }

    void checkInvalidTeamNameException(String teamName) throws InvalidTeamNameException {
        if (teamName.length() > 10) {
            System.out.println(teamName + " adlı takımın uzunluğu " + teamName.length() + " harf. 10 harften fazla olmamalı");
        }


        if (Objects.equals(teamName, "")) {
            System.out.println(teamName + " adlı takım ismi hatalıdır. Lütfen sadece büyük harf içeren bir isim giriniz");
            throw new InvalidTeamNameException();
        }


        for (int i = 0; i < teamName.length(); i++) {
            if (teamName.charAt(i) < 'A' || teamName.charAt(i) > 'Z'){
                System.out.println(teamName + " adlı takım ismi hatalıdır. Lütfen sadece büyük harf içeren bir isim giriniz");
            throw new InvalidTeamNameException();
            }
        }
    }

    void checkInvalidTotalGoalsException(int totalGoals) throws InvalidTotalGoalsException {

        if (totalGoals < 0) {
            System.out.println(totalGoals + " negatif bir sayıdır. Toplam gol sayısı negatif olamaz");
            throw new InvalidTotalGoalsException();
        }
        else if (totalGoals > 100) {
            System.out.println(totalGoals + " atılan gool sayısı, soruda yazılan kurallar gereği 100' den fazla olanaz");

        }
        else if (totalGoals == 0) {
            System.out.println(totalGoals + " tane gol olmaz, finalde illa ki bir gol atılır");

        }
    }
}
