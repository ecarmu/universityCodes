import java.util.ArrayList;
import java.util.Random;

public class WordPuzzle {
    char[][] grid;
    String[] word_list;

    WordPuzzle(char[][] grid, String[] word_list) {
        this.grid = new char[grid.length][grid.length];

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                this.grid[i][j] = grid[i][j];
            }
        }

        this.word_list = new String[word_list.length];

        for (int i = 0; i < word_list.length; i++) {
            this.word_list[i] = word_list[i];
        }

    }

    WordPuzzle(WordPuzzle wp) {
        this.grid= wp.grid;

        this.word_list = wp.word_list;
    }

    public String toString() {
        String str = "";

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                str += grid[i][j];
            }
            if (i == 0) {
                str += "      " + "Words: ";
            } else {
                if (i - 1 < word_list.length)
                    str += "      " + word_list[i - 1];
            }
            str += "\n";
        }
        return str;
    }

    public PuzzleSolution findWords() {

        PuzzleSolution ps = new PuzzleSolution();
        WordPuzzle wp = new WordPuzzle(this);

        // i ve j grid array' inde kontrol edilecek kelimelere geçmek için
        for (int i = 0; i < wp.grid.length; i++) {
            for (int j = 0; j < wp.grid.length; j++) {
                int rowInitial = i;
                int columnInitial = j;


                // " grid array' indeki bulunulan noktadaki char" ı, wordlistteki kelimelerle, teker teker kontrol ederken
                // "wordlist array' inde (kelimeden kelimeye) gezinmek için



                for (int k = 0; k < wp.word_list.length; k++) {

                    int counter = 0;
                    int wor_len = wp.word_list[k].length();
                    int orientateRow=0;
                    int orientateColumn=0;

                    if (word_list[k].charAt(counter) == wp.grid[rowInitial][columnInitial]) {
                        orientateRow = 0;
                        orientateColumn = 0;
                    }

                        for (int l = -1; l <= 1; l++) {
                            for (int m = -1; m <= 1; m++) {
                                if (rowInitial + l >= 0 && rowInitial + l <= 19 && columnInitial + m >= 0 && columnInitial + m <= 19) {
                                    if (wp.grid[rowInitial + l][columnInitial + m] == word_list[k].charAt(counter + 1)) {
                                        orientateRow = l;
                                        orientateColumn = m;
                                        WordOrientation wordOrientationSelected = null;

                                        switch (orientateRow) {
                                            case -1:
                                                switch (orientateColumn) {
                                                    case -1:
                                                        wordOrientationSelected = WordOrientation.BOTTOM_RIGHT_TO_TOP_LEFT;
                                                        break;
                                                    case 0:
                                                        wordOrientationSelected = WordOrientation.TO_TOP;
                                                        break;
                                                    case 1:
                                                        wordOrientationSelected = WordOrientation.BOTTOM_LEFT_TO_TOP_RIGHT;
                                                        break;
                                                }
                                                break;

                                            case 0:
                                                switch (orientateColumn) {
                                                    case -1:
                                                        wordOrientationSelected = WordOrientation.TO_LEFT;
                                                        break;
                                                    case 1:
                                                        wordOrientationSelected = WordOrientation.TO_RIGHT;
                                                        break;
                                                }
                                                break;

                                            case 1:
                                                switch (orientateColumn) {
                                                    case -1:
                                                        wordOrientationSelected = WordOrientation.TOP_RIGHT_TO_BOTTOM_LEFT;
                                                        break;
                                                    case 0:
                                                        wordOrientationSelected = WordOrientation.TO_BOTTOM;
                                                        break;
                                                    case 1:
                                                        wordOrientationSelected = WordOrientation.TOP_LEFT_TO_BOTTOM_RIGHT;
                                                        break;
                                                }
                                        }

                                        if (wordOrientationSelected == null){

                                            continue;
                                        }

                                        // (wordlist' te, şu an üstünde olduğumuz) kelimenin harflerinde dolaşmaya yarıyor
                                        // (başka deyişle) wordlist array' deki kelime (tahtada var mı diye) harf harf bakarız ya... harften harfe geçmek için
                                        WordPosition w1 = new WordPosition(word_list[k], rowInitial, columnInitial, wordOrientationSelected);
                                        while (counter != wor_len) {

                                            if (rowInitial < 0 || rowInitial > 19 || columnInitial < 0 || columnInitial > 19){
                                                rowInitial = i;
                                                columnInitial = j;
                                                counter = 0;
                                                break;
                                            }
                                            if (wp.grid[rowInitial][columnInitial] != word_list[k].charAt(counter)) {
                                                counter = 0;
                                                break;
                                            }
                                            counter++;
                                            rowInitial += w1.wordOrientation.getRow();
                                            columnInitial += w1.wordOrientation.getColumn();
                                        }

                                        if (counter == wor_len) {
                                            counter = 0;
                                            ps.wpst_arr.add(w1);
                                            rowInitial = i;
                                            columnInitial = j;
                                        }
                                        rowInitial = i;
                                        columnInitial = j;

                                    }
                                }
                            }
                        }


                }
            }
        }
        return new PuzzleSolution(ps);
    }

    public void printSolution(){
        System.out.println("\nPuzzle Solution");
        System.out.println(findWords());
    }





}
