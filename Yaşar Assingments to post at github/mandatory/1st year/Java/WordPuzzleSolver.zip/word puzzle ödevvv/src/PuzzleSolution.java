import java.util.ArrayList;

public class PuzzleSolution {
    ArrayList<WordPosition> wpst_arr;

    PuzzleSolution(PuzzleSolution ps) {
        wpst_arr = new ArrayList<>();
        for (int i = 0; i < ps.wpst_arr.size(); i++) {
            this.wpst_arr.add(ps.wpst_arr.get(i));
        }
    }

    public PuzzleSolution() {
        wpst_arr = new ArrayList<>();
    }


    public String toString() {
        String str = "";
        char[][] tmp_char_arr = new char[20][20];

        for (int i = 0; i < wpst_arr.size(); i++) {
            int row = wpst_arr.get(i).row_of_first_letter;
            int column = wpst_arr.get(i).column_of_first_letter;
            for (int j = 0; j < wpst_arr.get(i).word.length(); j++) {

                tmp_char_arr[row][column] = wpst_arr.get(i).word.charAt(j);
                row += wpst_arr.get(i).wordOrientation.getRow();
                column += wpst_arr.get(i).wordOrientation.getColumn();
            }
        }

        for (int i = 0; i < tmp_char_arr.length; i++) {
            for (int j = 0; j < tmp_char_arr.length; j++) {
                if(tmp_char_arr[i][j] == '\0')
                    tmp_char_arr[i][j] = ' '; // null' ların olduğu şeklini görmek istersen bu kısmı kaldır
                str += tmp_char_arr[i][j];
            }
            str += "\n";
        }
        return str;
    }
}

