public class WordPosition {
    String word;
    int row_of_first_letter;
    int column_of_first_letter;
    WordOrientation wordOrientation;

    WordPosition(WordPosition wpst) {
        this.word = wpst.word;
        this.row_of_first_letter = wpst.row_of_first_letter;
        this.column_of_first_letter = wpst.column_of_first_letter;
        this.wordOrientation = wpst.wordOrientation;
    }

    WordPosition(String word, int row_of_first_letter, int column_of_first_letter, WordOrientation wordOrientation) {
        this.word = word;
        this.row_of_first_letter = row_of_first_letter;
        this.column_of_first_letter = column_of_first_letter;
        this.wordOrientation = wordOrientation;
    }

    public String toString() {
        char[][] tmp_arr = new char[20][20];

        String[] str_tmp_arr = {word};
        WordPuzzle wp = new WordPuzzle(tmp_arr, str_tmp_arr);
        wp.grid = tmp_arr; // bu nasıl olur bilmiom

        int counter = 0;
        int i = row_of_first_letter;
        int j = column_of_first_letter;


        while (counter != word.length()) {
            wp.grid[i][j] = word.charAt(counter);
            counter++;
            i += wordOrientation.getRow();
            j += wordOrientation.getColumn();
        }

        String str = "";
        for (int row = 0; row < wp.grid.length; row++) {
            for (int column = 0; column < wp.grid.length; column++) {
                if(wp.grid[row][column] == '\0')
                    wp.grid[row][column] = ' ';
                // null olan halini görmek istersek, if bloğunu kaldırabiliriz
                str += wp.grid[row][column];
            }
            str += "\n";
        }
        str += "----------------" + "\n";

        return str;
    }

    public boolean intersects(WordPosition wpst) {
        int counter = 0;
        int row_us = row_of_first_letter;
        int column_us = column_of_first_letter;
        int wpst_row_initial = wpst.row_of_first_letter;
        int wpst_column_initial = wpst.column_of_first_letter;

        for (int i = 0; i < word.length(); i++) {
            while (counter != wpst.word.length()) {
                if (row_us == wpst.row_of_first_letter && column_us == wpst.column_of_first_letter) {
                    return true;
                }
                wpst.row_of_first_letter += wordOrientation.getRow();
                wpst.column_of_first_letter += wordOrientation.getColumn();
                counter++;
            }

            row_us += wordOrientation.getRow();
            column_us += wordOrientation.getColumn();
            wpst.row_of_first_letter = wpst_row_initial;
            wpst.column_of_first_letter = wpst_column_initial;
        }
        return false;
    }
}
