public enum WordOrientation {
    TO_RIGHT (0 , 1),
    TO_LEFT (0 , -1),
    TO_TOP (-1 , 0),
    TO_BOTTOM (1 , 0),
    TOP_LEFT_TO_BOTTOM_RIGHT (1 , 1),
    BOTTOM_RIGHT_TO_TOP_LEFT (-1 , -1),
    TOP_RIGHT_TO_BOTTOM_LEFT (1 , -1),
    BOTTOM_LEFT_TO_TOP_RIGHT (-1 , 1);

    private int row;
    private int column;

    WordOrientation (int row, int column){
        this.row = row;
        this.column = column;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }
}

