public class Demo {
    public static void main(String[] args) {




        // Kelimelerin dizimini, "oluşacak hataları tespit etmek" için, "cevapların etrafına" bilerek benzer kelimeler koydum

        /* Mesela sol üst köşede, bu şekilde koyup hata testi yaptım
               KI
               I

               Birkaç kelimede daha yaptım bunu
         */




        char[][] arr = new char[][]{
            {'K' ,'I' ,'T' ,'J' ,'X' ,'N' ,'O' ,'A' ,'Q' ,'Z' ,'G' ,'U' ,'G' ,'L' ,'M' ,'Y' ,'I' ,'Y' ,'H' ,'C'},
            {'L' ,'I' ,'A' ,'W' ,'S' ,'W' ,'L' ,'B' ,'N' ,'T' ,'G' ,'P' ,'B' ,'V' ,'W' ,'I' ,'I' ,'N' ,'E' ,'H'},
            {'J' ,'S' ,'N' ,'U' ,'E' ,'X' ,'Y' ,'M' ,'V' ,'D' ,'O' ,'Z' ,'W' ,'U' ,'D' ,'P' ,'D' ,'E' ,'Q' ,'E'},
            {'Z' ,'T' ,'I' ,'G' ,'E' ,'K' ,'A' ,'A' ,'G' ,'I' ,'S' ,'O' ,'F' ,'F' ,'X' ,'W' ,'X' ,'T' ,'D' ,'C'},
            {'F' ,'P' ,'Q' ,'P' ,'X' ,'F' ,'D' ,'G' ,'U' ,'S' ,'E' ,'L' ,'A' ,'Q' ,'N' ,'B' ,'E' ,'J' ,'C' ,'K'},
            {'U' ,'K' ,'F' ,'B' ,'U' ,'B' ,'A' ,'R' ,'O' ,'O' ,'K' ,'M' ,'N' ,'L' ,'A' ,'X' ,'J' ,'G' ,'O' ,'M'},
            {'X' ,'X' ,'I' ,'J' ,'Z' ,'M' ,'R' ,'Y' ,'D' ,'B' ,'M' ,'V' ,'I' ,'Y' ,'E' ,'X' ,'E' ,'Q' ,'X' ,'A'},
            {'B' ,'P' ,'R' ,'Y' ,'B' ,'N' ,'W' ,'Z' ,'T' ,'Z' ,'A' ,'N' ,'W' ,'A' ,'X' ,'I' ,'N' ,'D' ,'K' ,'T'},
            {'H' ,'R' ,'I' ,'I' ,'B' ,'B' ,'C' ,'M' ,'X' ,'Z' ,'M' ,'I' ,'E' ,'X' ,'E' ,'N' ,'M' ,'O' ,'R' ,'E'},
            {'W' ,'I' ,'T' ,'N' ,'D' ,'W' ,'J' ,'X' ,'N' ,'X' ,'X' ,'L' ,'Y' ,'E' ,'O' ,'U' ,'I' ,'M' ,'Y' ,'Y'},
            {'H' ,'E' ,'O' ,'O' ,'S' ,'H' ,'K' ,'F' ,'Q' ,'J' ,'P' ,'O' ,'S' ,'P' ,'U' ,'W' ,'E' ,'K' ,'H' ,'D'},
            {'U' ,'V' ,'M' ,'I' ,'S' ,'B' ,'Y' ,'E' ,'A' ,'L' ,'V' ,'P' ,'Y' ,'D' ,'I' ,'Q' ,'Y' ,'W' ,'B' ,'T'},
            {'N' ,'N' ,'Y' ,'V' ,'R' ,'E' ,'L' ,'I' ,'H' ,'N' ,'J' ,'R' ,'J' ,'P' ,'X' ,'W' ,'I' ,'G' ,'H' ,'M'},
            {'P' ,'N' ,'A' ,'B' ,'K' ,'B' ,'H' ,'M' ,'W' ,'U' ,'Y' ,'W' ,'C' ,'N' ,'K' ,'P' ,'C' ,'G' ,'A' ,'Y'},
            {'O' ,'T' ,'P' ,'H' ,'J' ,'T' ,'C' ,'S' ,'U' ,'S' ,'E' ,'B' ,'B' ,'C' ,'V' ,'R' ,'I' ,'B' ,'P' ,'T'},
            {'F' ,'R' ,'J' ,'O' ,'D' ,'I' ,'F' ,'G' ,'K' ,'J' ,'B' ,'S' ,'C' ,'B' ,'M' ,'N' ,'C' ,'B' ,'N' ,'U'},
            {'D' ,'F' ,'N' ,'I' ,'H' ,'Q' ,'M' ,'Y' ,'Z' ,'H' ,'N' ,'R' ,'G' ,'C' ,'K' ,'Q' ,'X' ,'Z' ,'W' ,'L'},
            {'S' ,'R' ,'W' ,'W' ,'F' ,'S' ,'R' ,'U' ,'Z' ,'L' ,'Y' ,'S' ,'I' ,'F' ,'R' ,'E' ,'W' ,'F' ,'Q' ,'C'},
            {'D' ,'C' ,'A' ,'G' ,'U' ,'K' ,'I' ,'Q' ,'F' ,'C' ,'H' ,'P' ,'O' ,'H' ,'S' ,'E' ,'R' ,'X' ,'U' ,'X'},
            {'K' ,'U' ,'P' ,'O' ,'H' ,'S' ,'I' ,'B' ,'H' ,'L' ,'B' ,'X' ,'P' ,'R' ,'R' ,'W' ,'E' ,'N' ,'M' ,'T'}
        };


        String[] word_list = {"KING" , "QUEEN", "GAMBIT" , "BISHOP" , "AROOK" , "ROOK", "KNIGHT" , "PAWN" , "CHECKMATE"};

        WordPuzzle wp = new WordPuzzle(arr, word_list);

        System.out.println("\nPuzzle: " + "\n" + wp);


        wp.printSolution();

    }


}
