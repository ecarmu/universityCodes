package chapter1.dxball;


import java.util.List;

public interface DXTileGenerator {
    List generate(DXBallArea dxBallArea);
}
