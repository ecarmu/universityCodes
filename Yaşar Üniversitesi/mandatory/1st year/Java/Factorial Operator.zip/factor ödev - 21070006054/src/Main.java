public class Main {

    public static void main(String[] args){
        Factor f1 = new Factor(3, 4);
        System.out.println("Test of f1 object:" + f1 + " -> " + f1.getFactor_result(f1.getBase(), f1.getBase()));

        Factor f2 = new Factor(3, 1);
        System.out.println("Test of f2 object:" + f2 + " -> " + f2.getFactor_result(f1.getBase(), f2.getBase()));

        System.out.println("Test of hasEqualValue: " + f1.hasEqualValue(f2));

        Factor f3 = f2.clone();
        System.out.println("Test of clone and equals: " + f2.equals(f3) + "\n\n");




       Number n1 = new Number(36);

        System.out.println("Test of n1 object: " + n1 + " -> " + n1.toInteger());

        Number n2 = new Number(9);



       System.out.println("Test of n2 object: " + n2 + " -> " + n2.toInteger());

        Number n4 = new Number((n1.add(n2)));

        System.out.println("Test_1 of 'add' method: " + "n1 + n2 = n4  ->  " + n4 + " -> " + n4.toInteger());

        Number n6 = new Number(n1.add(n4).add(n2));
        System.out.println("Test_2 of 'add' method: " + "n1 + n4 + n2  =  n6 -> " + n6 + " -> " + n6.toInteger());

        Number n33 = new Number(n4.multiplyBy(n2).add(n1).multiplyBy(n4));
        System.out.println("Test of 'add' and 'multiplyBy' methods: " + "( (n4 x n2) + n1 ) x n4)  =  n33 -> " + n33 + " -> " + n33.toInteger());


        System.out.println("\n\nMain deki n1:"  + n1.toInteger() + "  n2: "  + n2.toInteger() + "  n4: " + n4.toInteger() + "  n6: " + n6.toInteger() + "  n33:" + n33.toInteger());
    }
}
