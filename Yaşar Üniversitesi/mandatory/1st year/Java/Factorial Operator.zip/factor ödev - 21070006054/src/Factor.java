public class Factor {
    private int base;
    private int exponent;
    private int factor_result;

    Factor (int base, int exponent){
        this.base=base;
        this.exponent=exponent;
    }

    public String toString (){
        return base + "^" + exponent;
    }

    public int getBase() {
        return base;
    }

    public int getExponent() {
        return exponent;
    }

    public int getFactor_result(int base, int exponent) {
        factor_result =1;

        for (int i=0; i<exponent; i++){
            factor_result *= base;
        }

        return factor_result;
    }

    public void setBase(int base){
        this.base = base;
    }

    public void setExponent(int exponent){
        this.exponent = exponent;
    }


    Factor (Factor fctr){
        base=fctr.base;
        exponent=fctr.exponent;
        factor_result = fctr.getFactor_result(base, exponent);
    }


    public Factor clone(){
        return new Factor(this);
    }


    public boolean equals(Factor fctr){
        return (base==fctr.base && exponent== fctr.exponent);
    }

    public boolean hasEqualValue(Factor fctr){
        return (getFactor_result(base,exponent) == fctr.getFactor_result(fctr.getBase(),fctr.getExponent()));
    }

}
