import java.util.ArrayList;

public class Number {
    private int sayi;
    private ArrayList<Factor> carpan = new ArrayList<>();

    Number(int sayi){
        int sayi_orjinal = sayi;
        for (int i =2; i < sayi_orjinal; i++){
            int base = i;
            int exponent = 0;


            if (sayi%i == 0){
                for (int j=0; sayi%i == 0; j++){
                    sayi = sayi/i;
                    exponent++;
                }
                carpan.add(new Factor(base,exponent));

            }

        }
    }


    Number(Number nmbr){
        this.sayi=nmbr.sayi;

        for (int i=0; i<nmbr.carpan.size(); i++){
            this.carpan.add(i, nmbr.carpan.get(i));
        }
    }

    public String toString() {
        // Ola ki kullanıcı sayı olarak 1 girdi. Bu kısım çalışacak //
        String str="";
        if (carpan.size() == 0) {
            str += 1;
            return str;
        }


        str = carpan.get(0).getBase() + "^" + carpan.get(0).getExponent();

        for (int i = 1; i < carpan.size(); i++) {
            str += "." + carpan.get(i).getBase() + "^" + carpan.get(i).getExponent();
        }
        return str;
    }

    public int toInteger(){
        sayi=1;

        for (int i=0; i<carpan.size(); i++){
            sayi *= carpan.get(i).getFactor_result(carpan.get(i).getBase(), carpan.get(i).getExponent());
        }
        return sayi;
    }

    public Number multiplyBy(Number nmbr){

        Number depo_1 = new Number(sayi);

        //System.out.println("-" + depo_1);
        Number depo_2 = new Number(nmbr);

        //System.out.println("depolar ilk: " + depo_1.toInteger() + ", " + depo_2.toInteger() + ", "  + "normal: " + this.toInteger() + ", " + nmbr.toInteger());

        for (int i=0; i< depo_1.carpan.size() ;i++) {
            for (int j = 0; j < depo_2.carpan.size(); j++) {

                if (depo_1.carpan.get(i).getBase() == depo_2.carpan.get(j).getBase()) {
                    depo_1.carpan.get(i).setExponent(depo_1.carpan.get(i).getExponent() + depo_2.carpan.get(j).getExponent());
                    depo_2.carpan.remove(j);
                }
            }

        }
        //System.out.println("depolar son: " + depo_1.toInteger() + ", " + depo_2.toInteger() + ", "  + "normal: " + this.toInteger() + ", " + nmbr.toInteger());

        return depo_1;

        }


    public Number add(Number nmbr){

        Number n33 = new Number(this.toInteger() + nmbr.toInteger());
        n33.toInteger();
        return n33;
    }

}
