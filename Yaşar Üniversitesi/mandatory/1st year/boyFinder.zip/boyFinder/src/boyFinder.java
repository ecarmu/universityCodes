import java.sql.SQLOutput;
import java.util.ArrayList;

public class boyFinder {
    // belki static kullanabilirim
    String nicknameInitial;
    ArrayList<Character> usedWords;
    ArrayList <Character> nicknameTrimmed;
    int usedWordCount;

    // belki niickname trimmed kullanabilirim
    int distinctWordCount;

    boyFinder(String nicknameInitial) {
        this.nicknameInitial = nicknameInitial;
        nicknameTrimmed = new ArrayList<>();

        int arrSize = nicknameInitial.length();
        for (int i=0; i<arrSize; i++) {
            nicknameTrimmed.add(nicknameInitial.charAt(i));
        }

        usedWords = new ArrayList<>();
        
    }


    public int distinctWordCountFinder(){
        /*int lengthOfTrimmed = nicknameTrimmed.size();
        int lengthOfUsedWords = usedWords.size();*/

        int CountOfRemoveFromUsedWords = 0;

        boolean sameWord;
        boolean presentWordOfUsedWordUnremoved;

        for(int i = 0; i < nicknameInitial.length() -1 && i+1<nicknameTrimmed.size(); i++){
            sameWord = false;
            //presentWordOfUsedWordUnremoved = true;

            usedWords.add(nicknameTrimmed.get(i));
            for (int j = i + 1; j < nicknameTrimmed.size() ; j++) {


                if(usedWords.get(i-CountOfRemoveFromUsedWords) == nicknameTrimmed.get(j)){
                    /*if(presentWordOfUsedWordUnremoved){
                        nicknameTrimmed.remove(i);
                        presentWordOfUsedWordUnremoved = false;
                        j--;
                    }*/

                    sameWord = true;
                    nicknameTrimmed.remove(j);
                    j--;
                }
            }
            if(!sameWord){

                int lastIndexOfUsedWords = usedWords.size() - 1;
                usedWords.remove(lastIndexOfUsedWords);
                CountOfRemoveFromUsedWords++;
            }
        }

        distinctWordCount = nicknameTrimmed.size();
        System.out.println("distinctWordCount: " + distinctWordCount + " usedWordCount: " +  usedWords.size() + " nicknameTrimmed: " + nicknameTrimmed);
        return distinctWordCount;
    }

    public boolean boyOrGirlEvaluator () {
        return distinctWordCountFinder() % 2 == 0;
    }

    public void SystemMessage(){
        if(boyOrGirlEvaluator()){
            System.out.println("CHAT WITH HER!");
        }
        else
        {   System.out.println("IGNORE HIM!");  }

    }

}
