public class Main {

    public static void main(String[] args) {
        boyFinder bF1 = new boyFinder("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaba");
        bF1.SystemMessage();

        boyFinder bF2 = new boyFinder("wjmzbmr");
        bF2.SystemMessage();

        boyFinder bF3 = new boyFinder("ASDasd@");
        bF3.SystemMessage();
    }

}
