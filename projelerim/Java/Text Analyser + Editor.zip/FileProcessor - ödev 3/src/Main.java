import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        FileProcessor fileProcessor = new FileProcessor();

        try{


          fileProcessor.countWordsByLetter("sample.txt",
                    "boş_dolcak file.txt");

           // ** System.out.println(fileProcessor.countWords("sample.txt"));

            // ** System.out.println(fileProcessor.countOfWord("sample.txt", "the"));


          // ** fileProcessor.filterOut("sample.txt", "boş_dolcak file.txt", "the");

          // ** fileProcessor.filterByLength("sample.txt", "boş_dolcak file.txt", 7);
        } catch (FileProcessorException e) {

        }


    }

}
