import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class FileProcessor {
    FileProcessor(){

    }

    public void countWordsByLetter(String inputFileName, String outputFileName) throws FileProcessorException {
        String text = "";

        try {
            File inputFile = new File(inputFileName);
            Scanner scanner = new Scanner(inputFile);


            while(scanner.hasNextLine()){
                text += scanner.nextLine();
            }
        } catch (FileNotFoundException f){
            throw new FileProcessorException("FileNotFound Exception oldu");
        }


        char[] str_arr = new char[32];
        int[] int_arr = new int[32];
        char firstLetter;
        int k = 0;

        while (k<text.length()){

            if(text.charAt(k) == ' ' && text.charAt(k+1) != ' '){
                firstLetter = text.charAt(k+1);

                if(firstLetter>='a' && firstLetter<='z'){
                    firstLetter += 'A' - 'a';
                }

                for (int i = 0; i<str_arr.length; i++){
                    if ( firstLetter == str_arr[i]){
                        int letterCount = int_arr[i];
                        int_arr[i] = letterCount+1;
                        break;
                    }
                    else if(str_arr[i] == '\0'){
                        str_arr[i] = firstLetter;
                        int_arr[i] = 1;
                        break;
                    }
                }
            }
            else if(k == 0 && text.charAt(k) != ' '){
                firstLetter = text.charAt(0);
                if(firstLetter>='a' && firstLetter<='z'){
                    firstLetter += 'A' - 'a';
                }

                str_arr[0] = firstLetter;
                int_arr[0] += 1;
            }

            k++;
        }

        // alfabetik sıralı hale getirme kısmı
        char[] ordered_str_arr = new char[32];
        int[] ordered_int_arr = new int[32];

        for (int i = 0; i<str_arr.length; i++){
            int indexOfFirst = 0;
            char charFirst= str_arr[indexOfFirst];

            k = -1;

            do{
                k++;
                if(k>=32)
                    break;

                charFirst = str_arr[k];
                indexOfFirst = k;
            }while (str_arr[k] == '\0');


            for (int j = 0; j < str_arr.length; j++) {
                char charCurrent;
                if(str_arr[j] == '\0')
                    continue;
                else{
                    charCurrent = str_arr[j];
                }

                if((int) charCurrent<(int) charFirst){
                    charFirst = charCurrent;
                    indexOfFirst = j;
                }
            }
            ordered_str_arr[i] = (char) charFirst;
            ordered_int_arr[i] = int_arr[indexOfFirst];

            str_arr[indexOfFirst] = '\0';
        }
        // alfabetik sıralı hale getirme kısmı

        try{
            File outputFile = new File(outputFileName);
            FileWriter fileWriter = new FileWriter(outputFileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            String textOfOutput = "";

            for(int i = 0; i<str_arr.length; i++){

                if(ordered_str_arr[i] != '\0')
                    textOfOutput += ordered_str_arr[i] + ": " + ordered_int_arr[i] + '\n';
            }
            bufferedWriter.write(textOfOutput);
            bufferedWriter.close();

        } catch (IOException e) {
            throw new FileProcessorException("IOException oldu");
        }

    }

    public int countWords(String inputFileName) throws FileProcessorException {
        String textOfInput = "";
        try{
            File file = new File(inputFileName);
            Scanner scanner = new Scanner(file);
            while(scanner.hasNextLine()){
                textOfInput += scanner.nextLine();
            }
        } catch (FileNotFoundException e) {
            throw new FileProcessorException("FileNotFound Exception oldu");
        }


        char space = ' ';
        int word_count = 0;
        int i = 0;


        while (textOfInput.length() != i){
            if(i+1 == textOfInput.length()) {
                if(textOfInput.charAt(i)!=space)
                    word_count++;
            }

            else if(textOfInput.charAt(i) != space && textOfInput.charAt(i+1) == space){
                    word_count++;
                }
                i++;
        }
        return word_count;
    }

    public int countOfWord(String inputFileName, String key) throws FileProcessorException {
        String textOfInput = "";

        try{
            File file = new File(inputFileName);
            Scanner scanner = new Scanner(file);

            while(scanner.hasNextLine()){
                textOfInput += scanner.nextLine();
            }

        } catch (FileNotFoundException e) {
            throw new FileProcessorException("FileNotFound Exception oldu");
        }


        int word_count=0;



        for (int j = 0; j < textOfInput.length(); j++){
            char charNow = textOfInput.charAt(j);
            int i = 0;
            if(j!=0){
                if(textOfInput.charAt(j-1) != ' ')
                    if(textOfInput.charAt(j-1) < 33 || textOfInput.charAt(j-1)>46)
                    continue;
            }


            if( key.charAt(i) == textOfInput.charAt(j) || key.charAt(i) == textOfInput.charAt(j) - ('A' - 'a') ||  key.charAt(i) == textOfInput.charAt(j) + ('A' - 'a'))
            {
                i++;
                while (i<key.length()){
                    if(key.charAt(i)!=textOfInput.charAt(j+i)){
                        break;
                    }
                    i++;
                }

                if (i == key.length()){
                    if( (textOfInput.charAt(j+i) == ' ' || (textOfInput.charAt(j+i) >= 33 && textOfInput.charAt(j+i) <= 47) || j+i+1==textOfInput.length()) ){
                        word_count++;
                        if(j + i-1 > textOfInput.length()){
                            break;
                        }
                        else{
                            j+= i-1;
                        }
                    }


                }
                i=0;
            }
        }
        return word_count;
    }

    public void filterOut(String inputFileName, String outputFileName, String key) throws FileProcessorException {
        String textOfInput = "";
        try {
            File inputFile = new File(inputFileName);
            Scanner scanner = new Scanner(inputFile);
            while(scanner.hasNextLine()){
                textOfInput += scanner.nextLine();
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            throw new FileProcessorException("FileNotFound Exception oldu");
        }

        String textOfOutput = "";

        int i = 0;


        for (int j = 0; j != textOfInput.length(); j++){
            if( key.charAt(i) == textOfInput.charAt(j) || key.charAt(i) == textOfInput.charAt(j) - ('A' - 'a') ||  key.charAt(i) == textOfInput.charAt(j) + ('A' - 'a'))
            {
                i++;
                while (i<key.length()){
                    if(j+i >= textOfInput.length()){
                        break;
                    }

                    if(key.charAt(i)!=textOfInput.charAt(j+i)){
                        break;
                    }
                    i++;
                }
                if(j+i >= textOfInput.length()){
                    break;
                }
                if (i == key.length()){
                    i=0;
                    j += key.length()-1;
                    continue;
                }
            }
            textOfOutput += textOfInput.charAt(j);

        }


        try {
            File outputFile = new File(outputFileName);
            FileWriter fileWriter = new FileWriter(outputFileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(textOfOutput);
            bufferedWriter.close();

        } catch (IOException e) {
            throw new FileProcessorException("IOException oldu");
        }



    }

    public void filterByLength(String inputFileName, String outputFileName, int minWordLength) throws FileProcessorException {

        // gerekirse scanner ekleriz
        String st = "";
        String tmp_str = "";
        String textOfInput = "";


        try{
            File inputFile = new File(inputFileName);
            Scanner scanner = new Scanner(inputFile);

            while(scanner.hasNextLine()){
                textOfInput += scanner.nextLine();
            }
            scanner.close();
        } catch (IOException e) {
            throw new FileProcessorException("IOException oldu");
        }

        int i = 1;

        for (int j = 0; j < textOfInput.length(); j++){
            tmp_str = "";
            if(textOfInput.charAt(j) == ' ' && textOfInput.charAt(j+1) != ' ' )
            {
                tmp_str += textOfInput.charAt(j);
                if(j+i<textOfInput.length()){
                    while(textOfInput.charAt(j+i) != ' ' && textOfInput.charAt(j+i) != ','  && textOfInput.charAt(j+i) != '.'){
                        tmp_str += textOfInput.charAt(j+i);
                        i++;

                        if(j+i+1>textOfInput.length())
                            break;
                    }
                }



                if (i -1 >= minWordLength){
                    st+= tmp_str + " ";
                }
            }

            // index out of bounds alcaz gibi, çözümüne bakarız sonra

            if(j + i - 1> textOfInput.length()){
                break;
            }
            else {
                j += i-1;
                i = 1;
            }


        }

        try{
            File outputFile = new File(outputFileName);
            FileWriter fileWriter = new FileWriter(outputFileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(st);
            bufferedWriter.close();
        } catch (IOException e) {
            throw new FileProcessorException("IOException oldu");
        }

    }
}
