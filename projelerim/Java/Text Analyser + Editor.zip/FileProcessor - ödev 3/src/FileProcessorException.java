public class FileProcessorException extends Exception{
    FileProcessorException(String message){
        super(message);
    }
}
